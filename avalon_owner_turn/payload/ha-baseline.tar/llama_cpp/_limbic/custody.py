"""Bounded volatile custody. No serialization/repr includes secret material."""
import asyncio
from .transport import TARGET, ORIGINS, clean, ControlFailure


class Context:
    __slots__=('backend','key','lock','_capability','state','lifetime')
    def __init__(self,backend,key,lifetime):
        self.backend,self.key,self.lifetime=backend,key,lifetime
        self.lock=asyncio.Lock();self._capability=None;self.state='empty'


class Backend:
    def __init__(self, portal, channel):
        if portal not in ('owui','ha'):raise ValueError('Unknown backend')
        self.portal,self.channel=portal,channel
        self.contexts={}

    def owns(self, context):
        return type(context) is Context and context.backend is self and self.contexts.get(context.key) is context

    async def context(self,key,*,new=False,lifetime=None):
        ctx=self.contexts.get(key)
        if ctx is None:
            if len(self.contexts)>=128:return None
            ctx=Context(self,key,lifetime);self.contexts[key]=ctx
        if new:
            async with ctx.lock:
                if self.owns(ctx) and ctx.state=='empty':
                    ctx.state='pending'
                    try:
                        value=await self.channel.control('new')
                        if self.owns(ctx):ctx._capability=value;ctx.state='ready'
                    except BaseException:
                        if self.owns(ctx):ctx.state='uncertain'
                        raise
        return ctx

    def detach(self,ctx):
        if self.owns(ctx):
            self.contexts.pop(ctx.key);ctx._capability=None;ctx.state='detached'

    def detach_lifetime(self,lifetime):
        for ctx in list(self.contexts.values()):
            if ctx.lifetime is lifetime:self.detach(ctx)

    def headers(self,ctx,url,supplied):
        result=clean(supplied)
        if url in (TARGET,ORIGINS[self.portal]) and self.owns(ctx) and ctx.state=='ready':result.update(self.channel.headers(ctx._capability))
        return result

    async def control(self,ctx,operation):
        if not self.owns(ctx) or operation not in ('reset','revoke'):raise ControlFailure()
        async with ctx.lock:
            if not self.owns(ctx) or ctx.state!='ready':raise ControlFailure()
            cap=ctx._capability;ctx.state='pending'
            try:
                result=await self.channel.control(operation,cap)
                if not self.owns(ctx):raise ControlFailure()
                ctx._capability=result;ctx.state='ready' if operation=='reset' else 'revoked'
            except BaseException:
                if self.owns(ctx):ctx._capability=None;ctx.state='uncertain'
                raise

    async def transfer(self,source,destination,target):
        if (not self.owns(source) or not destination.owns(target) or destination is self
                or self.portal==destination.portal or self.channel.authority is not destination.channel.authority):raise ControlFailure()
        # Fixed two-backend order; only one process owns each map in this pass.
        first,second=sorted((source,target),key=lambda c:c.backend.portal)
        async with first.lock,second.lock:
            if not self.owns(source) or not destination.owns(target) or source.state!='ready' or target.state!='empty':raise ControlFailure()
            target.state='pending'
            try:
                await self.channel.control('transfer',source._capability)
                if not self.owns(source) or not destination.owns(target):raise ControlFailure()
                target._capability=source._capability;target.state='ready'
                return {'outcome':'shared'}
            except BaseException:
                if destination.owns(target):target.state='uncertain'
                raise


def request_headers(context,url,headers):
    if type(context) is Context:return context.backend.headers(context,url,headers)
    return clean(headers)
