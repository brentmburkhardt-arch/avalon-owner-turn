"""Fixed production TLS channel; admission authority stays in Executive."""
import asyncio
import hmac
import json
import hashlib
import httpx
import re
import ssl
from .owner_turn import RESERVED

_IN_PROCESS_CLIENT = httpx.AsyncClient

CAP = 'x-avalon-conversation-admission'
AUTH = 'x-avalon-backend-authorization'
BASE = 'https://192.168.1.104:8443'
ORIGINS = {'owui':'http://avalon-executive:8010/v1/chat/completions',
           'ha':'http://192.168.1.104:8010/v1/chat/completions'}
TARGET = BASE+'/v1/chat/completions'

def valid_cap(value):
    return type(value) is str and re.fullmatch(r'[0-9a-f]{32}',value) is not None


def clean(headers):
    items = headers.items() if hasattr(headers, 'items') else headers
    return {k:v for k,v in items if k.lower() not in (CAP, AUTH, *RESERVED)}


class ControlFailure(Exception):
    def __init__(self):super().__init__('Admission control unconfirmed')


class Gateway:
    """Single Executive owner and two fixed backend credential verifiers."""
    def __init__(self, app, sessions, verifiers):
        self.app, self.sessions = app, sessions
        if set(verifiers) != {'owui','ha'} or any(not re.fullmatch(r'[0-9a-f]{64}', v) for v in verifiers.values()):
            raise ValueError('Invalid backend verifier configuration')
        if verifiers['owui'] == verifiers['ha']:raise ValueError('Distinct backend credentials required')
        self._verifiers=dict(verifiers)
        self.controls=0

    def authenticated_portal(self, headers):
        values=[v for k,v in headers if k.lower()==AUTH.encode()]
        if len(values)!=1 or not isinstance(values[0],bytes):return False
        # 256 random bits, encoded as hex. A verifier is never accepted as a bearer.
        raw=values[0]
        if not re.fullmatch(rb'Bearer [0-9a-f]{64}',raw):return False
        digest=hashlib.sha256(raw[7:]).hexdigest()
        matches=[p for p,v in self._verifiers.items() if hmac.compare_digest(digest,v)]
        return matches[0] if len(matches)==1 else None

    def authorized(self, headers):
        return bool(self.authenticated_portal(headers))

    @staticmethod
    def capability(headers):
        values=[v for k,v in headers if k.lower()==CAP.encode()]
        if len(values)!=1:return None
        try:raw=values[0].decode('ascii')
        except (AttributeError,UnicodeError):return None
        return raw if valid_cap(raw) else None

    async def __call__(self, scope, receive, send):
        if scope['type']!='http':return await self.app(scope,receive,send)
        headers=scope.get('headers',[])
        portal=self.authenticated_portal(headers)
        trusted=bool(portal)
        cap=self.capability(headers) if trusted else None
        path=scope.get('path','')
        if path.startswith('/_limbic/'):
            code=401;result={'outcome':'unauthorized'}
            if trusted:
                code=400;result={'outcome':'invalid_control'}
                if scope['method']=='POST' and path in ('/_limbic/new','/_limbic/reset','/_limbic/revoke','/_limbic/transfer'):
                    empty=True
                    while True:
                        message=await receive()
                        if message.get('type')!='http.request' or message.get('body'):
                            empty=False;break
                        if not message.get('more_body'):break
                    cap_headers=[v for k,v in headers if k.lower()==CAP.encode()]
                    if empty and ((path=='/_limbic/new' and not cap_headers) or (path!='/_limbic/new' and cap is not None)):
                        try:
                            self.controls+=1
                            def control():
                                owner=self.sessions
                                if owner is None:raise ControlFailure()
                                if path=='/_limbic/new':return {'outcome':'admitted','capability':owner.admit()}
                                if path=='/_limbic/reset':return {'outcome':'reset','capability':owner.reset(cap)}
                                if path=='/_limbic/revoke':return {'outcome':'revoked','removed':owner.revoke(cap)}
                                with owner.engine.guard:
                                    owner._require_available();owner._expire()
                                    if owner._digest(cap) not in owner.admitted:raise ControlFailure()
                                    return {'outcome':'transferable'}
                            result=await asyncio.to_thread(control);code=200
                        except Exception:
                            code=503;result={'outcome':'unconfirmed'}
            raw=json.dumps(result,separators=(',',':')).encode()
            await send({'type':'http.response.start','status':code,'headers':[(b'content-type',b'application/json'),(b'cache-control',b'no-store'),(b'x-should-retry',b'false')]})
            return await send({'type':'http.response.body','body':raw})
        scope=dict(scope)
        scope['headers']=[(k,v) for k,v in headers if k.lower() not in (CAP.encode(),AUTH.encode(),*(n.encode() for n in RESERVED))]
        scope['avalon.authenticated_portal']=portal if trusted else None
        scope['avalon.owner_turn']=None
        if trusted:
            from app.limbic.owner_turn import parse
            scope['avalon.owner_turn']=parse(headers,portal)
        scope['avalon.session_binding']=None
        if trusted and cap and path=='/v1/chat/completions' and scope['method']=='POST':
            try:scope['avalon.session_binding']=self.sessions.resolve(cap,owner_turn=scope['avalon.owner_turn']) if self.sessions else None
            except Exception:pass
        await self.app(scope,receive,send)


class Channel:
    """Fixed verified TLS destination; controls have no retry or redirect path."""
    def __init__(self, credential, ca_file):
        if type(credential) is not str or not re.fullmatch(r'[0-9a-f]{64}',credential):
            raise ValueError('Invalid private configuration')
        self.authority=BASE
        self._credential=credential
        self.tls=ssl.create_default_context(cafile=ca_file)
        self.http=_IN_PROCESS_CLIENT(transport=httpx.AsyncHTTPTransport(verify=self.tls,retries=0),base_url=BASE,follow_redirects=False,trust_env=False)

    async def close(self):await self.http.aclose()

    def headers(self, cap):
        if not valid_cap(cap):return {}
        return {AUTH:'Bearer '+self._credential,CAP:cap}

    async def control(self, operation, cap=None):
        if operation not in ('new','reset','revoke','transfer'):raise ControlFailure()
        headers={AUTH:'Bearer '+self._credential}
        if cap is not None:headers[CAP]=cap
        try:
            from .privacy import private_errors
            with private_errors(headers):
                response=await self.http.post('/_limbic/'+operation,headers=headers,content=b'')
            if response.status_code!=200:raise ControlFailure()
            data=response.json()
            expected={'new':'admitted','reset':'reset','revoke':'revoked','transfer':'transferable'}[operation]
            if type(data) is not dict or data.get('outcome')!=expected:raise ControlFailure()
            if operation in ('new','reset'):
                if set(data)!={'outcome','capability'} or not valid_cap(data['capability']):raise ControlFailure()
                return data['capability']
            if operation=='revoke':
                if set(data)!={'outcome','removed'} or type(data['removed']) is not bool:raise ControlFailure()
            elif set(data)!={'outcome'}:raise ControlFailure()
            return None
        except asyncio.CancelledError:raise
        except Exception:pass
        raise ControlFailure() from None
