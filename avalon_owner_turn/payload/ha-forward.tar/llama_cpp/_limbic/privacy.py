"""Request-scoped redaction for the backend SDK/portal transport seams."""
from contextlib import contextmanager
from contextvars import ContextVar
import logging
import httpx

_secrets=ContextVar('native_portal_private_values',default=())


def sanitized(error):
    """Keep SDK error category/status and stack; discard provider text/requests."""
    if type(error).__module__.startswith('openai'):
        result=Exception.__new__(type(error))
        result.args=('Executive request failed',)
        result.message='Executive request failed'
        result.request=httpx.Request('POST','https://192.168.1.104:8443/v1/chat/completions')
        result.body=None;result.code=None;result.param=None;result.type=None
        status=getattr(error,'status_code',None)
        if type(status) is int:
            result.status_code=status
            result.response=httpx.Response(status,request=result.request,json={'error':{'message':'Executive request failed'}})
            result.request_id=None
    else:
        result=RuntimeError('Executive request failed')
    return result.with_traceback(error.__traceback__)


def erase_private_exception(error):
    # Mutate the escaping exception's data, retaining its type and traceback.
    # A contextmanager raising a replacement can retain the original secret-
    # bearing error in __context__, even with "from None". Do not retain it.
    safe=sanitized(error)
    error.args=safe.args
    error.__dict__.clear();error.__dict__.update(safe.__dict__)
    for name in ('filename','filename2'):
        if hasattr(error,name):setattr(error,name,None)
    error.__context__=None;error.__cause__=None;error.__suppress_context__=True


class Redact(logging.Filter):
    def filter(self,record):
        values=_secrets.get()
        if not values:return True
        try:message=record.getMessage()
        except Exception:message='Private transport diagnostic'
        for value in values:
            if value:message=message.replace(value,'[redacted]')
        record.msg=message;record.args=()
        if record.exc_info and record.exc_info[1]:
            exc=sanitized(record.exc_info[1]);record.exc_info=(type(exc),exc,exc.__traceback__);record.exc_text=None
        return True


# Logger filters do not apply to records emitted by descendant loggers.
# Sanitize at creation, before framework handlers/queues, only while the
# private request ContextVar is active. Preserve any installed record factory.
_previous_factory=logging.getLogRecordFactory()
_redactor=Redact()
def _private_record(*args,**kwargs):
    record=_previous_factory(*args,**kwargs)
    _redactor.filter(record)
    return record
logging.setLogRecordFactory(_private_record)


@contextmanager
def private_errors(headers):
    # Header values never escape through a diagnostic repr or exception value.
    full=tuple(v for k,v in headers.items() if k.lower() in ('x-avalon-conversation-admission','x-avalon-backend-authorization','x-avalon-owner-turn'))
    values=full+tuple(v.removeprefix('Bearer ') for v in full)
    token=_secrets.set(values)
    try:yield
    except StopAsyncIteration:raise
    except Exception as error:
        if not values:raise
        erase_private_exception(error)
        raise
    finally:_secrets.reset(token)
