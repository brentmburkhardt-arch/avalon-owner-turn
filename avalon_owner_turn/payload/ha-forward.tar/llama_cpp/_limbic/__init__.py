"""Avalon backend-only volatile portal custody. No model-facing interface."""
