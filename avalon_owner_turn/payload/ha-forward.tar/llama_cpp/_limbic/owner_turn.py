"""Backend-local owner action context; never admission authority or user data."""
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from functools import wraps
import secrets

TOKEN = 'x-avalon-owner-turn'
KIND = 'x-avalon-owner-turn-kind'
RESERVED = (TOKEN, KIND)


@dataclass(frozen=True, repr=False)
class _Turn:
    token: str
    kind: str


_current = ContextVar('avalon_owner_turn', default=None)
_auxiliary = ContextVar('avalon_auxiliary_origin', default=False)


def owner_action(function):
    """One native invocation, before fan-out; tasks inherit private context only."""
    @wraps(function)
    async def wrapped(*args, **kwargs):
        try:
            turn = _Turn(secrets.token_hex(16), 'auxiliary' if _auxiliary.get() else 'primary')
        except Exception:
            turn = None  # Entropy failure cannot prevent ordinary semantic work.
        marker = _current.set(turn)
        origin = _auxiliary.set(False)
        try:
            result = await function(*args, **kwargs)
            # Inline StreamingResponse consumption can outlive the native call.
            # Preserve only private context around iteration; bytes and scheduling
            # remain with the native iterator, with no additional task or request.
            iterator = getattr(result, 'body_iterator', None)
            if iterator is not None:
                result.body_iterator = _iterate(iterator, turn)
            return result
        finally:
            _auxiliary.reset(origin)
            _current.reset(marker)
    return wrapped


@contextmanager
def auxiliary():
    """Only the fixed native parent-result resume call site supplies this origin."""
    marker = _auxiliary.set(True)
    try:
        yield
    finally:
        _auxiliary.reset(marker)


def headers():
    turn = _current.get()
    return {TOKEN: turn.token, KIND: turn.kind} if type(turn) is _Turn else {}


async def _iterate(iterator, turn):
    try:
        while True:
            marker = _current.set(turn)
            try:
                chunk = await anext(iterator)
            except StopAsyncIteration:
                return
            finally:
                _current.reset(marker)
            yield chunk
    finally:
        if hasattr(iterator, 'aclose'):
            marker = _current.set(turn)
            try:
                await iterator.aclose()
            finally:
                _current.reset(marker)
