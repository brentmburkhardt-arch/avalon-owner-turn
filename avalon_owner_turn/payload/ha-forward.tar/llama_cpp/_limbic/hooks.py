"""Private release-overlay hooks. Backend-only registration for the controlled production shadow pilot."""
import httpx
from .custody import Backend, Context, request_headers
from .transport import TARGET, BASE, ORIGINS, CAP, AUTH, clean
from .privacy import private_errors
from .owner_turn import RESERVED

_owui=None
_ha={}


def install_owui(backend):
    global _owui
    assert type(backend) is Backend and backend.portal=='owui'
    _owui=backend


def install_ha(agent,backend):
    assert type(backend) is Backend and backend.portal=='ha'
    _ha[id(agent)]=(agent,backend)


async def owui_context(chat_id,*,new=False,direct=False,internal=False):
    if (_owui is None or direct or internal or type(chat_id) is not str or not chat_id
            or chat_id.startswith(('temporary:','local:','channel:'))):return None
    try:return await _owui.context(('saved',chat_id),new=new)
    except Exception:return None


async def ha_context(agent,session,chat_log,sessions):
    registered=_ha.get(id(agent))
    if not registered or registered[0] is not agent or session is None:return None
    if session.conversation_id!=chat_log.conversation_id:return None
    backend=registered[1]
    key=(agent.entry.entry_id,agent.subentry.subentry_id,id(session))
    new=sessions.get(session.conversation_id) is not session
    try:
        first=key not in backend.contexts
        context=await backend.context(key,new=new,lifetime=session)
        if first and context:
            session.async_on_cleanup(lambda:backend.detach(context))
        return context
    except Exception:return None


def ha_unload(agent):
    registered=_ha.pop(id(agent),None)
    if registered and registered[0] is agent:
        backend=registered[1]
        for ctx in list(backend.contexts.values()):
            if ctx.key[:2]==(agent.entry.entry_id,agent.subentry.subentry_id):backend.detach(ctx)


class PrivateContent:
    def __init__(self,inner,headers):self.inner,self.headers=inner,headers
    async def _iterate(self,iterator):
        while True:
            try:
                with private_errors(self.headers):value=await anext(iterator)
            except StopAsyncIteration:return
            yield value
    def __aiter__(self):return self._iterate(self.inner.__aiter__())
    def iter_any(self):return self._iterate(self.inner.iter_any().__aiter__())
    def iter_chunks(self):return self._iterate(self.inner.iter_chunks().__aiter__())
    def iter_chunked(self,n):return self._iterate(self.inner.iter_chunked(n).__aiter__())


class PrivateResponse:
    def __init__(self,response,headers):
        self._response=response;self._private=headers
        self.status=response.status
        if hasattr(response,'content'):self.content=PrivateContent(response.content,headers)
        self.headers=httpx.Headers(clean(response.headers))
        full=tuple(headers.get(k,'') for k in (CAP,AUTH,RESERVED[0]))
        secrets=full+tuple(value.removeprefix('Bearer ') for value in full)
        self.headers=httpx.Headers({k:v for k,v in self.headers.items() if not any(s and s in str(v) for s in secrets)})
        if self.status>=300:self.headers=httpx.Headers({'Content-Type':'application/json'})
    def __getattr__(self,name):return getattr(self._response,name)
    async def json(self,**kwargs):
        if self.status>=300:return {'error':{'message':'Executive request failed'}}
        with private_errors(self._private):return await self._response.json(**kwargs)
    async def text(self,**kwargs):
        if self.status>=300:return '{"error":{"message":"Executive request failed"}}'
        with private_errors(self._private):return await self._response.text(**kwargs)


async def owui_request(session,**kwargs):
    protected=kwargs['url'] in (TARGET,ORIGINS['owui']) and CAP in kwargs['headers']
    if protected:
        if _owui is None:raise RuntimeError('Private backend unavailable')
        kwargs['url']=TARGET
        kwargs['ssl']=_owui.channel.tls
    if not protected:return await session.request(**kwargs)
    with private_errors(kwargs['headers']):
        response=await session.request(**kwargs,allow_redirects=False)
        if 300<=response.status<400:
            response.close()
            raise RuntimeError('Executive redirect rejected')
    return PrivateResponse(response,kwargs['headers'])


class BorrowedHTTP(httpx.AsyncClient):
    """Request-local view; the native or private backend retains client ownership."""
    def __init__(self,inner,headers):
        self.inner=inner;self.private=headers
    @property
    def timeout(self):return self.inner.timeout
    @property
    def is_closed(self):return self.inner.is_closed
    def build_request(self,*args,**kwargs):return self.inner.build_request(*args,**kwargs)
    async def send(self,request,**kwargs):
        for name in (CAP,AUTH,*RESERVED):request.headers.pop(name,None)
        if str(request.url)==TARGET:
            request.headers.update(self.private)
            kwargs['follow_redirects']=False
        with private_errors(self.private):return await self.inner.send(request,**kwargs)
    async def aclose(self):pass  # The shared HA client retains ownership.


def ha_client(client,context):
    url=str(client.base_url).rstrip('/')+'/chat/completions'
    if url not in (TARGET,ORIGINS['ha']):return client,{}
    headers=request_headers(context,url,{})
    # OpenAI 2.45.0 copy/set_default_headers reuses options/retry policy/pool.
    # It does not mutate the shared client's defaults. HTTP defaults are scrubbed
    # after request construction, before send, by the borrowed client view.
    bound=CAP in headers and type(context) is Context and context.backend.owns(context)
    inner=context.backend.channel.http if bound else client._client
    copied=client.with_options(set_default_headers=clean(client.default_headers),
                               base_url=BASE+'/v1' if bound else client.base_url,
                               timeout=client.timeout,
                               http_client=BorrowedHTTP(inner,headers))
    return copied,headers
