"""Private file activation; missing or invalid configuration leaves chat unbound."""
import json
import os
import stat
from pathlib import Path
from .custody import Backend
from .transport import Channel, ORIGINS
from . import hooks

ENTRY='01M0RKDE69R9H1DWM4WJYKYH5J'
SUBENTRY='01M0RKDE692GCFV6QQMFVPS5XE'
_backends={}

def private_json(path):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as file:
        st=os.fstat(file.fileno())
        if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or stat.S_IMODE(st.st_mode)!=0o600:
            raise ValueError('Private file permissions')
        raw=file.read(4097)
    if len(raw)>4096:raise ValueError('Private configuration size')
    return json.loads(raw)

def backend(portal,root):
    if portal in _backends:return _backends[portal]
    try:
        data=private_json(root/(portal+'.json'))
        keys={'version','portal','credential'} | ({'entry','subentry'} if portal=='ha' else set())
        if set(data)!=keys or data['version']!=1 or data['portal']!=portal:raise ValueError('Private binding')
        if portal=='ha' and (data['entry']!=ENTRY or data['subentry']!=SUBENTRY):raise ValueError('Private binding')
        owner=Backend(portal,Channel(data['credential'],str(root/'ca.pem')))
        _backends[portal]=owner
        return owner
    except Exception:return None

async def owui_start():
    owner=backend('owui',Path('/run/avalon-limbic/owui'))
    if owner:hooks.install_owui(owner)

def ha_start(agent):
    if (agent.entry.entry_id==ENTRY and agent.subentry.subentry_id==SUBENTRY
            and str(agent.entry.data.get('base_url','')).rstrip('/')+'/chat/completions'==ORIGINS['ha']
            and agent.subentry.data.get('chat_model')=='lyra'):
        owner=backend('ha',Path(agent.hass.config.path('.avalon-limbic/private')))
        if owner:hooks.install_ha(agent,owner)

async def close(portal):
    owner=_backends.pop(portal,None)
    if owner:
        for context in list(owner.contexts.values()):owner.detach(context)
        await owner.channel.close()
    if portal=='owui':hooks._owui=None
