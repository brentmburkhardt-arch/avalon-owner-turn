"""Conversation support for llama.cpp."""
from ._limbic.owner_turn import owner_action
from ._limbic.hooks import ha_context, ha_unload
from ._limbic.bootstrap import ha_start
from homeassistant.helpers.chat_session import current_session, DATA_CHAT_SESSION

from typing import Literal, override

from homeassistant.components import conversation
from homeassistant.config_entries import ConfigEntry, ConfigSubentry
from homeassistant.const import CONF_LLM_HASS_API, CONF_PROMPT, MATCH_ALL
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from . import LlamaCppConfigEntry
from .const import DOMAIN
from .entity import LlamaCppBaseLLMEntity


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: LlamaCppConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up conversation entities."""
    for subentry in config_entry.subentries.values():
        async_add_entities(
            [LlamaCppConversationEntity(config_entry, subentry)],
            config_subentry_id=subentry.subentry_id,
        )


class LlamaCppConversationEntity(
    conversation.ConversationEntity,
    conversation.AbstractConversationAgent,
    LlamaCppBaseLLMEntity,
):
    """llama.cpp conversation agent."""

    def __init__(self, entry: ConfigEntry, subentry: ConfigSubentry) -> None:
        """Initialize the agent."""
        super().__init__(entry, subentry)
        if self.subentry.data.get(CONF_LLM_HASS_API):
            self._attr_supported_features = (
                conversation.ConversationEntityFeature.CONTROL
            )

    @property
    @override
    def supported_languages(self) -> list[str] | Literal["*"]:
        """Return a list of supported languages."""
        return MATCH_ALL

    @override
    async def async_added_to_hass(self) -> None:
        """When entity is added to Home Assistant."""
        await super().async_added_to_hass()
        conversation.async_set_agent(self.hass, self.entry, self)
        ha_start(self)

    @override
    async def async_will_remove_from_hass(self) -> None:
        """When entity will be removed from Home Assistant."""
        ha_unload(self)
        conversation.async_unset_agent(self.hass, self.entry)
        await super().async_will_remove_from_hass()

    @override
    @owner_action
    async def _async_handle_message(
        self,
        user_input: conversation.ConversationInput,
        chat_log: conversation.ChatLog,
    ) -> conversation.ConversationResult:
        """Process a sentence."""
        options = self.subentry.data

        try:
            await chat_log.async_provide_llm_data(
                user_input.as_llm_context(DOMAIN),
                options.get(CONF_LLM_HASS_API),
                options.get(CONF_PROMPT),
                user_input.extra_system_prompt,
            )
        except conversation.ConverseError as err:
            return err.as_conversation_result()

        private_context = await ha_context(
            self, current_session.get(), chat_log, self.hass.data.get(DATA_CHAT_SESSION, {}),
        )
        await self._async_handle_chat_log(chat_log, _limbic_context=private_context)

        return conversation.async_get_result_from_chat_log(user_input, chat_log)
